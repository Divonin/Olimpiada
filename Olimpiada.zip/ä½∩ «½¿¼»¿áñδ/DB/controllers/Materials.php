<?php

require ('db.php');

class Materials extends DB
{
    public function GetData(){
        return $this->DBAll('SELECT * from materials');
    }
    public function createMaterials($request){
        $req = json_decode($request);
        $name = $req->name;
        $price = $req->price;
        $count = $req->count;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO materials (name,price,count) values ('{$name}','{$price}','{$count}')");
            $connect->commit();
            return json_encode([
                'message'=>'Услуга добавлена'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateMaterials($request){
        $req = json_decode($request);
        $id_materials = $req->id_materials;
        $name = $req->name;
        $price = $req->price;
        $count = $req->count;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE materials SET name='{$name}', price='{$price}', count='{$count}' WHERE id_materials={$id_materials} ");
            $connect->commit();
            return json_encode([
                'message'=>'Заказ обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}