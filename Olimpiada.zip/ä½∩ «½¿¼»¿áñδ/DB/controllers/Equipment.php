<?php

require ('db.php');

class Equipment extends DB
{
    public function Getdata(){
        return $this->DBAll('SELECT * from equipment');
    }
    public function createEquipment($request){
        $req = json_decode($request);
        $name = $req->name;
        $affiliation = $req->affiliation;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO equipment (name,affiliation) values ('{$name}','{$affiliation}')");
            $connect->commit();
            return json_encode([
                'message'=>'Услуга добавлена'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateEquipment($request){
        $req = json_decode($request);
        $id_equipment = $req->id_equipment;
        $name = $req->name;
        $affiliation = $req->affiliation;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE equipment SET name='{$name}', affiliation='{$affiliation}' WHERE id_equipment={$id_equipment} ");
            $connect->commit();
            return json_encode([
                'message'=>'Заказ обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}