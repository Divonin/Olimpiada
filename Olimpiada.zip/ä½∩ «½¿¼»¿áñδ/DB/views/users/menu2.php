<div>
    <a class="knopka" href="../../index2.php">Главная</a>
</div>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <div>Сотрудники</div>
    <div>
        <a class="knopka" href="update_user.php">Изменить пользователя</a>
        <a class="knopka" href="delete_user.php">Удалить пользователя</a>
    </div>
</div>