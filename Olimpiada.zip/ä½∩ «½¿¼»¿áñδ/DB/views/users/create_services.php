<?php
require('../layout/header.php');
require_once('menu.php');
require('../../controllers/Services.php');
$db = new Services();
?>
<div class="container mt-5">
    <form action="../../middleware/createServices.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-5">
            <label for="service">Название</label>
            <input id="service" name="service" type="text" class="form-control" placeholder="Введите название услуги" required>
        </div>
        <div class="col-5">
            <label for="deadlines">Сроки</label>
            <input id="deadlines" name="deadlines" type="text" class="form-control" placeholder="Введите сроки ремонта" required>
        </div>
    <div class="col-5">
            <label for="price">Стоимость</label>
            <input id="price" name="price" type="text" class="form-control" placeholder="Стоимость" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Добавить</button>
        </div>
    </form>
</div>
