<div>
    <a class="knopka" href="../auth/menu.php">В меню</a>
</div>
<?php
require ('../layout/header.php');
require_once('../../controllers/Orders.php');
?>
    <div class="container mt-5">
        <form action="../../middleware/staff/createStaff.php"
              method="post"
              class="d-flex flex-column justify-content-center align-items-center">
            <h3>Создание</h3>
            <?php
            $a = date("Y-m-d");
            ?>
            <div class="col-5">
                <label for="start">Старт</label>
                <input id="start" name="start" type="date" value="<?php echo $a?>" min="<?php echo $a?>" class="form-control" placeholder="Начало работы" required>
            </div>
            <div class="col-5">
                <label for="end">Окончание</label>
                <input id="end" name="end" type="date" class="form-control"  min="<?php echo $a?>" max="2022-12-27" placeholder="Окончание работы" required>
            </div>
            <div class="col-5">
                <label for="names">Название услуги</label>
                <input id="names" name="names" type="text" class="form-control" placeholder="Введите название услуги" required>
            </div>
            <div class="col-5">
                <label for="price">Стоимость</label>
                <input id="price" name="price" type="text" class="form-control" placeholder="Стоимость" required>
            </div>
            <div class="mt-3">
                <button class="btn btn-primary" type="submit">Отправить</button>
            </div>
        </form>
    </div>
