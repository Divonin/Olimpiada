<div>
    <a class="knopka" href="../auth/menu.php">В меню</a>
</div>
<?php
require_once('../layout/header.php');
require_once('../../controllers/Orders.php');
$db = new Orders();
?>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th>id</th>
        <th>Начало</th>
        <th>Конец</th>
        <th>Название услуги</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->get();
    foreach ($data as $key => $row) {
        ?>
        <tr>
            <form class="mx-2" action="../../middleware/staff/update.php" method="post">
                <td>
                    <?php echo ++$key; ?>
                    <input id="id_orders" name="id_orders" type="text" value="<?php echo $row["id_orders"]; ?>" class="form-control" hidden
                           required>
                </td>
                <td>
                    <input id="start" name="start" type="date" value="<?php echo $row["start"]; ?>" class="form-control"
                           required>
                </td>
                <td>
                    <input id="end" name="end" type="date" value="<?php echo $row["end"]; ?>" class="form-control"
                           required>
                </td>
                <td>
                    <input id="names" name="names" type="text"
                           value="<?php echo $row["names"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="price" name="price" type="text" value="<?php echo $row["price"]; ?>"
                           class="form-control" required>
                </td>
                <td>
                    <button type="submit" class="btn btn-primary">Изменить</button>
                </td>
            </form>
        </tr>
    <?php } ?>
    </tbody>
</table>
