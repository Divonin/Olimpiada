<?php
require_once('../layout/header.php');
require_once('../../controllers/Equipment.php');
$db = new Equipment();
?>
<div>
    <a class="knopka" href="../auth/menu.php">В меню</a>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th>id</th>
        <th>Название</th>
        <th>Назначение</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->getData();
    foreach ($data as $key => $row) {
        ?>
        <tr>
            <form class="mx-2" action="../../middleware/staff/updateEquipment.php" method="post">
                <td>
                    <?php echo ++$key; ?>
                    <input id="id_equipment" name="id_equipment" type="text" value="<?php echo $row["id_equipment"]; ?>" class="form-control" hidden
                           required>
                </td>
                <td>
                    <input id="name" name="name" type="text" value="<?php echo $row["name"]; ?>" class="form-control"
                           required>
                </td>
                <td>
                    <input id="affiliation" name="affiliation" type="text" value="<?php echo $row["affiliation"]; ?>"
                           class="form-control" required>
                </td>
                <td>
                    <button type="submit" class="btn btn-primary">Изменить</button>
                </td>
            </form>
        </tr>
    <?php } ?>
    </tbody>
</table>
