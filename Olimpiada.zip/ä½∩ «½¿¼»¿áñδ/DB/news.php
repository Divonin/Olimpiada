<?php
require ('views/layout/header.php');
?>
<div class="d-flex">
    <a class="knopka" href="/index.php">Назад</a>
</div>
<style>
label.labelor{
    color: #ffffff;
    background-color: #0c63e4;
}
</style>
<style>
    label.border_widthed{
        border-style: solid;
        border-color: #60ee9f;
        border-width:1px 1px 1px 1px; /* толщина линий */
        box-shadow: 0 0 10px #90e1b7;
        padding: .1em .5em;
        border-radius: 10px;
    }
</style>
<div>
<label class="labelor container d-flex align-items-center p-1 mb-auto border_widthed">
Тут пока нет новостей, потому что это курсовой проект, эта ИС пока не в эксплуатации
</label>
</div>