<?php
require_once('views/layout/header.php');
require_once('controllers/Services.php');
?>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<div class="w3-content w3-section" >

  <img class="mySlides w3-animate-fading" src="images/1.png" style="width:100%">
  <img class="mySlides w3-animate-fading" src="images/2.png" style="width:100%">
  <img class="mySlides w3-animate-fading" src="images/3.png" style="width:100%">
  <img class="mySlides w3-animate-fading" src="images/4.png" style="width:100%">
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 9000);    
}
</script>
</div>
    <div class="buttones">
            <a class="knopka" href="/views/auth/auth.php">Авторизация</a>
        </div>
        <div class="logo">
            <a href="/index.php"><img src="images/pngwing.com.png" alt="images/pngwing.com.png" width="60"></a>
        </div>
<?php
if (isset($_GET['message'])) {
    echo $_GET['message'];
}
?>
    <div class="container mx-auto">
        <div style="display: grid; grid-template-columns: repeat(3,1fr)">
            <?php
            $user = new Services();
            $data = $user->getData();
            foreach ($data as $key => $row) {
                ?>
    <div>
    <figure class="snip1336">
        <figcaption>
            <h4><?php echo $row['service']; ?><span>"Печка, утюг и другие"</span></h4>
            <p>Сроки:<?php echo $row['deadlines']; ?> </p>
            <p>Стоимость:<?php echo $row['price']; ?> </p>
        </figcaption>
    </figure>
</div>
<?php } ?>