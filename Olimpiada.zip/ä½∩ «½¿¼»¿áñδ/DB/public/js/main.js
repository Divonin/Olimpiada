function testJS() {
    var a = document.getElementById('service').value,
        url = 'http://localhost:8080/views/auth/index.php/create.php?name=' + encodeURIComponent(a);
    document.location.href = url;
    var b = document.getElementById('price').value,
        url = 'http://localhost:8080/views/auth/index.php/create.php?name=' + encodeURIComponent(b);
    document.location.href = url;
}