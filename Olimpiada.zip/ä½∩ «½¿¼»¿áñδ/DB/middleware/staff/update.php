<?php
require_once('../../controllers/Orders.php');
$db = new Orders();
$id_orders = $_POST['id_orders'];
$start = $_POST['start'];
$end = $_POST['end'];
$names = $_POST['names'];
$price = $_POST['price'];

$res = $db->updateOrders(json_encode([
    'id_orders'=>$id_orders,
    'start'=>$start,
    'end'=>$end,
    'names'=>$names,
    'price'=>$price,
]));

header('Location: ../../views/auth/menu.php?message='.json_decode($res)->message);
