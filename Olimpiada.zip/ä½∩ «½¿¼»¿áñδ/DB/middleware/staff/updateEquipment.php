<?php
require_once('../../controllers/Equipment.php');
$db = new Equipment();
$id_equipment = $_POST['id_equipment'];
$name = $_POST['name'];
$affiliation = $_POST['affiliation'];

$res = $db->updateEquipment(json_encode([
    'id_equipment'=>$id_equipment,
    'name'=>$name,
    'affiliation'=>$affiliation,

]));

header('Location: ../../views/staff/equipment.php?message='.json_decode($res)->message);
