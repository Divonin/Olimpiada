<?php
require_once ('../../controllers/Orders.php');
$db = new Orders();
$id_orders = $_POST['id_orders'];

$res = $db->deleteOrders(json_encode([
    'id_orders'=>$id_orders
]));

header('Location: ../../views/auth/menu.php?message='. json_decode($res)->message);