<?php
require('../../controllers/Equipment.php');
$db = new Equipment();
$name = $_POST['name'];
$affiliation = $_POST['affiliation'];
$response = $db->createEquipment(json_encode([
    'name'=>$name,
    'affiliation'=>$affiliation,

]));

header('Location: ../../views/staff/equipment.php?message='.json_decode($response)->message);
