<?php
require('../controllers/Services.php');
$db = new Services();
$service = $_POST['service'];
$deadlines = $_POST['deadlines'];
$price = $_POST['price'];

$response = $db->createServices(json_encode([
    'service'=>$service,
    'deadlines'=>$deadlines,
    'price'=>$price,
]));

header('Location: ../index2.php?message='.json_decode($response)->message);