<?php
header('Location: ../../views/auth/registration.php');