<?php
require_once('../controllers/User.php');
$db = new User();
$id_users = $_POST['id_users'];
$password = $_POST['password'];

$response = $db->updateU(json_encode([
    'id_users'=>$id_users,
    'password'=>$password,
]));

header('Location: ../index2.php?message='.json_decode($response)->message);
