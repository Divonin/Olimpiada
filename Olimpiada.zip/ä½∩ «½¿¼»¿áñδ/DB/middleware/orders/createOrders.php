<?php
require_once('../../controllers/order.php');
$db = new order();
$start = $_POST['start'];
$names = $_POST['names'];

$response = $db->createOrder(json_encode([
    'start'=>$start,
    'names'=>$names,
]));

header('Location: ../../views/auth/index.php?message='.json_decode($response)->message);
